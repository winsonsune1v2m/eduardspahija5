#!/usr/bin/python
#coding:utf-8

import re
import json
import MySQLdb
import sys
import redis

r = redis.Redis(host="127.0.0.1",port=6379)

database_info = r.get("database_info")
database_info = json.loads(database_info.decode("utf-8"))
sql_host = database_info["HOST"]
sql_user = database_info["USER"]
sql_passwd = database_info["PASSWORD"]
sql_db = database_info["NAME"]

print(sql_host,sql_user,sql_passwd,sql_db)
